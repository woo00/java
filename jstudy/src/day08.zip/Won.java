package day08;

public class Won {
	int ban;
	double area;
	double doole;
	public void setArea() {
		area = ban*ban*3.14;
	}
	public void setDoole() {
		doole = 2*ban*3.14;
	}
}
