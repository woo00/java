package day08;

public class Nemo {
	int garo, sero;
	int around;
	int area;

	 public void setAround() {
		 around = (garo*2)+(sero*2);
	 }
	 public void setArea() {
		 area = garo*sero;
	 }
}
