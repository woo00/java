package day08;

public class Semo {
	int garo, sero;
	double area;
	//넓이계산용 함수 
	public void setArea() {
		area = garo * sero * 0.5;
	}
}
