package oday02;

public class Test03 {

	public static void main(String[] args) {
		for(int i = 'A'; i <= 'Z' ; i++) {
			System.out.println("############ " + (char) i);
		}
	}

}
