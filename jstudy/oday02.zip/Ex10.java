package oday02;

public class Ex10 {
/*
	문제 8 ]
		정수 3개를 입력받아서
		세 수중 제일 큰수만 출력해주는 프로그램을 작성하세요.
 */
	public static void main(String[] args) {
		
	}

}
