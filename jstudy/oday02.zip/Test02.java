package oday02;

public class Test02 {
	public static void main(String[ ] args) {
		int no = (int)(Math.random()*(10 - 1 + 1) + 1);
		
		int no2 = (int)(Math.random()*101) + 100 ;
		// ==> (int)(Math.random()*(큰수 - 작은수 + 1) + 작은수)
	}
}
