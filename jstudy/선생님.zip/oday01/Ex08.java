package oday01;

public class Ex08 {
/*
 	문제 8 ]
 		1 1 1 1 1
 		2 2 2 2 2
 		3 3 3 3 3
 		4 4 4 4 4
 		5 5 5 5 5

 */
	public static void main(String[] args) {
		for(int i = 0 ; i < 5; i++ ) {
			for(int j = 0 ; j < 5 ; j++ ) {
				int num = i + 1;
				System.out.print(num + " ");
			}
			System.out.println();
		}
	}

}
