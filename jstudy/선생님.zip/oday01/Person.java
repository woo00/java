package oday01;

public class Person {
	public String name, gen, mail, tel;
	public int age;
	public double height;
}
