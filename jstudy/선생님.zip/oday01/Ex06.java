package oday01;

public class Ex06 {
/*
 	문제 6]
 		*****
 		*****
 		*****
 		*****
 		*****
 */
	public static void main(String[] args) {
		// 별다섯개만 출력해본다.
		
		// 위의 결과를 다섯번 반복한다.

	}

}
