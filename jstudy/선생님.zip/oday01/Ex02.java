package oday01;

public class Ex02 {
/*
	문제 2 ]
		'A' 부터 문자를 10개를 만들어서 출력하세요.
 */
	public static void main(String[] args) {
		// 결과값 변수 만든다.
		String result = "";
		for(int i = 0 ; i < 10; i++ ) {
			// 문자 만든다.
			
			// 문자 출력하고
			
			// 문자열에 더해준다.
			
		}
		// 문자열 출력한다.
		System.out.println("result : " + result);
	}

}
