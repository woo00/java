package oday01;

public class Ex09 {
/*
 	
 	문제 9 ]
 		12345
 		23456
 		34567
 		45678
 		56789

 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
