package oday01;

public class Ex07 {
/*
 	문제 7 ]
 		*
 		**
 		***
 		****
 		*****

 */
	public static void main(String[] args) {
		
	}

}
