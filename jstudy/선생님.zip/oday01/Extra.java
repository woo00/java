package oday01;

public class Extra {

	public static void main(String[] args) {
		// 1234 숫자를 4321로 만드세요.
		int no = 1234;
		int num = 0;
		
		String tmp = 1234 + "";
		String sno = "";
		for(int i = tmp.length() - 1 ; i >= 0 ; i-- ) {
			sno = sno + tmp.charAt(i);
		}
		
		num = Integer.parseInt(sno);
		System.out.println("no : " + no);
		System.out.println("num : " + num);
		
	}

}
