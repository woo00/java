package oday01;

public class Extra02 {

	public static void main(String[] args) {
		char ch = (char) (97 + 10);
		System.out.println(ch);
	}

}
