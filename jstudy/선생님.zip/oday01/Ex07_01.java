package oday01;

public class Ex07_01 {
/*
 	문제 7-1 ]
 	
 *****
 ****
 ***
 **
 *
 	
 	문제 7-2 ]
 	
     *
    **
   ***
  ****
 *****
 	
 	문제 7-3 ]
 	
     *
    ***
   *****
  *******
 *********

 */
	public static void main(String[] args) {
		
	}

}
