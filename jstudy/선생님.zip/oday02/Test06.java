package oday02;

public class Test06 {

	public static void main(String[] args) {
		int num = (int)Math.pow(2, 11);
		
		num = 2 << 10; 
		// << : shift 연산자... 2 * 2^10
		// >> : / 2^10
		
		System.out.println(num);
	}

}
