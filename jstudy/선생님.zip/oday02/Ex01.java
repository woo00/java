package oday02;

public class Ex01 {
/*
문제 1 ]

 1  2  3  4  5
 6  7  8  9 10
11 12 13 14 15
16 17 18 19 20
21 22 23 24 25


방법은 두가지...

1. 
2. 카운터변수(i, j)로만 숫자를 생성하는 방법

 */
	public static void main(String[] args) {
		for(int i = 0 ; i < 5 ; i++ ) {
			for(int j = 0 ; j < 5 ; j++ ) {
				System.out.printf("%3d", 5 * i + j + 1);
			}
			System.out.println();
		}
	}

}
