package oday02;

public class Test00 {
/*
문제 7-3 ]
 	
     *
    ***
   *****
  *******
 *********

 */
	public static void main(String[] args) {
		/*
		int no = 10;
		
		Integer num = no;
		
		String str = num.toString();
		
		System.out.println(str);
		String num2 = no + "";
		System.out.println(num2);
		
		*/
	}

}
