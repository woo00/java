package oday02;

public class Ex10 {
/*
	문제 8 ]
		정수 3개를 입력받아서
		세 수중 제일 큰수만 출력해주는 프로그램을 작성하세요.
		
		extra ]
			세수중 제일 큰 수, 중간 수, 작은 수를 판별해서 출력하세요. 
 */
	public static void main(String[] args) {
		int no1 = (int)(Math.random()*100);
		int no2 = (int)(Math.random()*100);
		int no3 = (int)(Math.random()*100);
		
		
	}

}
