package oday03;

/*
	문제 2 ]
		두자리 숫자 두개를 입력받아서
		두수의 최소공배수를 구해서 출력해주는 프로그램을 작성하세요.
		
		참고 ]
			최소공배수
				두수의 배수중 최소 숫자.
				
			최대공약수
				두수의 공통 약수중 최대 숫자.
 */
public class Ex02 {

	public static void main(String[] args) {
		
	}

}
