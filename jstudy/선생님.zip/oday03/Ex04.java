package oday03;

/*
	문제 4 ]
		3 ~ 100사이의 숫자 하나를 랜덤하게 발생시켜서
		이 숫자가 소수인지 판별해주는 프로그램을 작성하세요.
		
		참고 ]
			소수 : 1과 자기자신 이외에 나눌수 있는 수가 없는 수
 */
public class Ex04 {

	public static void main(String[] args) {
		
	}

}
